import logo from './logo.svg';
import './App.css';
import CounterApp from './components/CounterApp';
import AuthComponent from './components/AuthComponent';
import RestAppComponent from './components/RestAppComponent';

function App() {
  return (
    <div className="App">
      <RestAppComponent/>
    </div>
  );
}

export default App;
