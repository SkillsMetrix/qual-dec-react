
import axios from 'axios'
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { createAPIThunk } from './createAPIThunk';
import { getPosts } from './postAPI';

export const fetchUsers= createAPIThunk(
    "posts/fetchposts",
     getPosts
)
export const fetchUsersSlice= createSlice({
    name:"posts",
    initialState:{
        list:[],
        loading:false,
        error:null
    },
    reducers:{},
    extraReducers:(builder)=>{
        builder
        .addCase(fetchUsers.pending,(state) =>{
            state.loading= true
        })
        .addCase(fetchUsers.fulfilled,(state,action) =>{
            state.loading=false
            state.list=action.payload
        })
        .addCase(fetchUsers.rejected,(state,action) =>{
            state.loading=false
            state.error=action.payload
        })
    }
})
export default fetchUsersSlice.reducer