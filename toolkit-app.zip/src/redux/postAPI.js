import appClient from "../apiClient"


export const getPosts=()=>{
    return appClient.get('/users')
}