import { createAsyncThunk } from "@reduxjs/toolkit"


export const createAPIThunk= (type,apiCall) =>{

   return createAsyncThunk(type,async(_,{rejectWithValue})=>{
        try {
            const response= await apiCall()
            return response.data
        }catch(error){
            return rejectWithValue(error.message)
        }
    })
}