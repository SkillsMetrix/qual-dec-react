import { configureStore } from '@reduxjs/toolkit'
import counterReducer from './counterSlice'
import authReducer from './authSlice'
import postReducer from './RestAppSlice'
 
export default configureStore({
    reducer:{
        countapp:counterReducer,
        auth:authReducer,
        post:postReducer
    }
})