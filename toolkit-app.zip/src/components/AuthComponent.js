
 
import { useDispatch, useSelector } from 'react-redux'
import { login, logout } from '../redux/authSlice';
 function AuthComponent(props) {
    const isLogin= useSelector(state=> state.auth.isLogin)
    const dispatch= useDispatch()
    return (
        <div>
            <h2> Only For Authorized Users Only</h2>

            {isLogin ? (
                <div>
                    <p> Congratulations....! you got 50% discount . Use Coupon code <strong>HJPOU897ADL</strong>  </p>
                    </div>
            ): (
                <p>Login to see the offer</p>
            )}
            
            <hr/>
            <button onClick={(()=> dispatch(login()))}>Login</button>
             <button onClick={(()=> dispatch(logout()))}>Logout</button>
        </div>
    );
}

export default AuthComponent;