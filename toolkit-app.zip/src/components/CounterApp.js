import React from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { increment } from '../redux/counterSlice';
function CounterApp(props) {
    const data= useSelector(state => state.countapp.counter)
    const dispatch= useDispatch()
    return (
        <div>
            the count is : {data}
            <hr/>
            <button onClick={()=> dispatch(increment())}>INC</button>
        </div>
    );
}

export default CounterApp;