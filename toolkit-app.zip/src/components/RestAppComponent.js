import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { fetchUsers } from '../redux/RestAppSlice';
function RestAppComponent(props) {
    const {loading,list,error} = useSelector((state)=> state.post)
    const dispatch= useDispatch()
   
    const loadUsers=()=>{
        dispatch(fetchUsers())
    }
    if(loading) return <p>Loading....!</p>
       if(error) return <p>Error....!{error}</p>
    return (
        <div>
            <button onClick={()=>loadUsers()}>loadUsers</button>
            <ul>
                {list.slice(0,5).map((post) =>(
                    <div key={post.id}>
                        <li >{post.name}</li>
                    </div>
                ))}
            </ul>
        </div>
    );
}

export default RestAppComponent;