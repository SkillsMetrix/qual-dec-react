import ProductListing from "./components/ProductListing";

export const routes=[
    {path:'/', element:<ProductListing/>}
]