import React from 'react';

function Header(props) {
    return (
        <div className='ui fixed menu'>
            <div className='ui container center'>
                <h3>UserShop</h3>
            </div>
            
        </div>
    );
}

export default Header;