import React from 'react';

function ProductDetails(props) {
    return (
        <div>
            
        </div>
    );
}

export default ProductDetails;