

import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { fetchItem } from '../redux/apiSlice';
function AppClient(props) {
    const {data,loading}= useSelector(state => state.api)
    const dispatch= useDispatch()
    useEffect(()=>{
        dispatch(fetchItem("/users/1"))
    },[])
    return (
        <div>
            
        </div>
    );
}

export default AppClient;