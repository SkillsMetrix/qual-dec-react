import { apiCall, getUserByID, login } from "./apiService";
import {
  fetchList,fetchItem,listSuccess,itemSuccess,
  loginSuccess
} from "./apiSlice";
import { call, put, takeLatest } from "redux-saga/effects";

function* fetchListSaga(action) {
  const response = yield call(apiCall, action.payload);
  yield put(listSuccess(response.data));
}
function* fetchItemSaga(action) {
  const response = yield call(apiCall, action.payload);
  yield put(itemSuccess(response.data));
}
function* loginSaga(action){
  const res= yield(login,action.payload)
  yield put(loginSuccess(res.data.access_token))
}
function* fetchItemFromServerSaga(action) {
  const response = yield call(getUserByID, action.payload);
  yield put(itemSuccess(response.data));
}
export default function* rootSaga() {
  yield takeLatest(fetchList.type,fetchListSaga);
  yield takeLatest(fetchItem.type,fetchItemSaga);
   yield takeLatest('auth/login',loginSaga);
   yield takeLatest('user/getbyid',fetchItemFromServerSaga)
}
