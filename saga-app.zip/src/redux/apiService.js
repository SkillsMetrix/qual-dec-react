import axiosInstance from "./axiosInstance";

export const login =(username) => axiosInstance.post('/oauth/token',username)
export const apiCall =(url)=> axiosInstance.get(url)
export const getUserByID=(id) => axiosInstance.get(`/users/${id}`)