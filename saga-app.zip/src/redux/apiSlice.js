import { createSlice } from "@reduxjs/toolkit";

const apiSlice = createSlice({
  name: "api",
  initialState: {
    data: [],
    item: null,
    token:null,
    loading: false,
  },
  reducers: {
    loginSuccess:(state,action) =>{
      state.token= action.payload
      localStorage.setItem('access-token',action.payload)
    },
    fetchList: (state) => {
      state.loading = true;
    },
    fetchItem: (state) => {
      state.loading = true;
    },
    listSuccess: (state, action) => {
      state.list = action.payload;
      state.loading = false;
    },
    itemSuccess: (state, action) => {
      state.item = action.payload;
      state.loading = false;
    },
  },
});
export const { fetchItem,fetchList,listSuccess,itemSuccess,loginSuccess } = apiSlice.actions;
export default apiSlice.reducer;
